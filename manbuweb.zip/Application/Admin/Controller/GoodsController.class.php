<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Model;
class GoodsController extends Controller {
	public function index(){
		
	}

	public function lists(){
		$this->display();
	}

	public function add(){
		$this->display();
	}
}