<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model;
class ProductController extends Controller {
	public function index(){
		$this->display();
	}
}